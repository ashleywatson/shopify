if (!customElements.get('product-form')) {
  customElements.define(
    'product-form',
    class ProductForm extends HTMLElement {
      constructor() {
        super();

        this.form = this.querySelector('form');
        this.variantIdInput.disabled = false;
        this.form.addEventListener('submit', this.onSubmitHandler.bind(this));
        this.cart = document.querySelector('cart-notification') || document.querySelector('cart-drawer');
        this.submitButton = this.querySelector('[type="submit"]');
        this.submitButtonText = this.submitButton.querySelector('span');
        this.template = this.dataset.productTemplate;

        if (document.querySelector('cart-drawer')) this.submitButton.setAttribute('aria-haspopup', 'dialog');

        this.hideErrors = this.dataset.hideErrors === 'true';
      }

      onSubmitHandler(evt) {
        evt.preventDefault();
        if (this.submitButton.getAttribute('aria-disabled') === 'true') return;

        this.handleErrorMessage();

        this.submitButton.setAttribute('aria-disabled', true);
        this.submitButton.classList.add('loading');
        this.querySelector('.loading__spinner').classList.remove('hidden');

        const config = fetchConfig('javascript');
        config.headers['X-Requested-With'] = 'XMLHttpRequest';
        delete config.headers['Content-Type'];

        const formData = new FormData(this.form);
        if (this.cart) {
          formData.append(
            'sections',
            this.cart.getSectionsToRender().map((section) => section.id)
          );
          formData.append('sections_url', window.location.pathname);
          this.cart.setActiveElement(document.activeElement);
        }
        config.body = formData;

        fetch(`${routes.cart_add_url}`, config)
          .then((response) => response.json())
          .then((response) => {
            if (response.status) {
              publish(PUB_SUB_EVENTS.cartError, {
                source: 'product-form',
                productVariantId: formData.get('id'),
                errors: response.errors || response.description,
                message: response.message,
              });
              this.handleErrorMessage(response.description);

              const soldOutMessage = this.submitButton.querySelector('.sold-out-message');
              if (!soldOutMessage) return;
              this.submitButton.setAttribute('aria-disabled', true);
              this.submitButtonText.classList.add('hidden');
              soldOutMessage.classList.remove('hidden');
              this.error = true;
              return;
            } else if (!this.cart) {
              window.location = window.routes.cart_url;
              return;
            }

            if (!this.error)
              publish(PUB_SUB_EVENTS.cartUpdate, {
                source: 'product-form',
                productVariantId: formData.get('id'),
                cartData: response,
              });
            this.error = false;
            const quickAddModal = this.closest('quick-add-modal');
            if (quickAddModal) {
              document.body.addEventListener(
                'modalClosed',
                () => {
                  setTimeout(() => {
                    this.cart.renderContents(response);
                  });
                },
                { once: true }
              );
              quickAddModal.hide(true);
            } else {
              this.cart.renderContents(response);
            }
          })
          .catch((e) => {
            console.error(e);
          })
          .finally(() => {
            this.submitButton.classList.remove('loading');
            if (this.cart && this.cart.classList.contains('is-empty')) this.cart.classList.remove('is-empty');
            if (!this.error) this.submitButton.removeAttribute('aria-disabled');
            this.querySelector('.loading__spinner').classList.add('hidden');
          });
      }

      handleErrorMessage(errorMessage = false) {
        if (this.hideErrors) return;

        this.errorMessageWrapper =
          this.errorMessageWrapper || this.querySelector('.product-form__error-message-wrapper');
        if (!this.errorMessageWrapper) return;
        this.errorMessage = this.errorMessage || this.errorMessageWrapper.querySelector('.product-form__error-message');

        this.errorMessageWrapper.toggleAttribute('hidden', !errorMessage);

        if (errorMessage) {
          this.errorMessage.textContent = errorMessage;
        }
      }

      toggleSubmitButton(disable = true, text) {
        if (disable) {
          this.submitButton.setAttribute('disabled', 'disabled');
          if (text) this.submitButtonText.textContent = text;
        } else {
          this.submitButton.removeAttribute('disabled');
          if(this.template == 'preorder'){
            this.submitButtonText.textContent = window.variantStrings.preOrder;
          }
          else{
            this.submitButtonText.textContent = window.variantStrings.addToCart;
          }
        }
      }

      get variantIdInput() {
        return this.form.querySelector('[name=id]');
      }
    }
  );
}

function replaceStars() {
  const replacements = [
    { selector: '.kl_reviews__full_star', newClass: 'aw-custom-star' },
    { selector: '.kl_reviews__empty_star', newClass: 'aw-custom-star-empty' }
  ];

  replacements.forEach(({ selector, newClass }) => {
    document.querySelectorAll(selector).forEach(function (svg) {
      if (svg.dataset.replaced === 'true') return;

      const replacement = document.createElement('div');
      replacement.classList.add(newClass);
      replacement.style.width = svg.getAttribute('width') || '16px';
      replacement.style.height = svg.getAttribute('height') || '16px';

      svg.dataset.replaced = 'true';
      svg.replaceWith(replacement);
    });
  });
}

document.addEventListener("DOMContentLoaded", function () {
  replaceStars();

  const observer = new MutationObserver(function (mutations) {
    mutations.forEach(function (mutation) {
      mutation.addedNodes.forEach(function (node) {
        if (node.nodeType !== 1) return;

        if (
          node.matches('.kl_reviews__full_star, .kl_reviews__empty_star') ||
          node.querySelector('.kl_reviews__full_star, .kl_reviews__empty_star')
        ) {
          replaceStars();
        }
      });
    });
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
});


function setupScrollButton() {
  const button = document.querySelector('.kl_reviews__button');
  const scrollContainers = document.querySelectorAll('.kl_reviews__list_container > div');

  if (button && scrollContainers.length > 0 && !button.dataset.scrollSetup) {
    button.addEventListener('click', () => {
      const vw = Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0);
      const scrollAmount = vw * 0.4;

      console.log(`Clicked; scrolling containers 40vw (${scrollAmount}px):`);
      scrollContainers.forEach((container, index) => {
        console.log(`Container ${index + 1}:`, container);

        setTimeout(() => {
          container.scrollBy({
            left: scrollAmount,
            behavior: 'smooth'
          });
        }, 500);
      });
    });

    button.dataset.scrollSetup = 'true';
  }
}

// Watch DOM changes until both are found
function observeScrollSetup() {
  const observer = new MutationObserver(() => {
    const button = document.querySelector('.kl_reviews__button');
    const scrollContainer = document.querySelector('.kl_reviews__list_container > div');

    if (button && scrollContainer) {
      setupScrollButton();
      observer.disconnect();
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
}

document.addEventListener('DOMContentLoaded', () => {
  setupScrollButton();
  observeScrollSetup();
});